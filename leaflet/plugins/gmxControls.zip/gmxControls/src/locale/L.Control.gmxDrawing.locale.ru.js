L.extend(L.Control.GmxDrawing.locale, {
    rus: {
        'Point': 'Маркер',
        'Polygon': 'Многоугольник',
        'Polyline': 'Линия',
        'Rectangle': 'Прямоугольник'
    }
});
