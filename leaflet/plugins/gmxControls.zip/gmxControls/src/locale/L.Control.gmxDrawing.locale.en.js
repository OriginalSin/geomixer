L.extend(L.Control.GmxDrawing.locale, {
    eng: {
        'Point': 'Point',
        'Polygon': 'Polygon',
        'Polyline': 'Polyline',
        'Rectangle': 'Rectangle'
    }
});
