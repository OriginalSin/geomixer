#!/bin/bash

gulp svgCheck
