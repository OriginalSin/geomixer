﻿
var mapsSite = true;
var gmxAuthServer = 'http://my.kosmosnimki.ru/';
// window.gmxSkipTiles = 'NotVisible';  // в описании основной карты НЕ выдавать списки тайлов для не видимых слоев
window.gmxSkipTiles = 'All';  // в описании основной карты НЕ выдавать списки тайлов для не видимых слоев
// window.isGeneralized = false;    	// По умолчанию генерализация включена для всех слоев

//var gmxJSHost = 'http://maps.kosmosnimki.ru/api/';
var serverBase = 'http://maps2.kosmosnimki.ru/';


var gmxGeoCodeUseOSM = true;
// настройки карты
var mapOptions = {
	// svgSprite: 'leaflet/plugins/gmxControls/dist/css/img/svg-symbols.svg',
	svgSprite: true,
	maxPopupCount: 10
};
// if (window.location.search.match('svgIcons=true')) {
	// mapOptions.svgSprite = 'leaflet/plugins/gmxControls/dist/css/img/svg-symbols.svg';
// }
var controlsOptions = {
	gmxLoaderStatus: {type: 'font'}
	// gmxDrawing: {items: ['Rectangle', 'Polyline', 'Point', 'Polygon']},
	// gmxLocation: {scaleFormat: 'text'},
	// gmxCopyright: {cursorPosition: true}
	// ,
	// gmxHide: {isActive: false}
	//gmxLogo: null
};

window.gmxPlugins = [
     { pluginName: 'Timeline Vectors', file: 'plugins/external/GMXPluginTimeLine/L.Control.gmxTimeLine.js', module: 'gmxTimeLine', mapPlugin: true, isPublic: true },
    // { pluginName: 'WindAnimation', file: 'plugins/external/GMXPluginWindAnimation/WindAnimation.js', module: 'WindAnimation', mapPlugin: true, isPublic: true },
 
    {pluginName: 'Cadastre',             file: 'plugins/external/GMXPluginCadastre/cadastre.js',         module: 'cadastre',           mapPlugin: true,  isPublic: false, params: {notHideDrawing: false}},
    { pluginName: 'VideoLayers', file: 'plugins/external/GMXPluginVideoLayers/VideoLayers.js', module: 'VideoLayers', mapPlugin: true, isPublic: true },
    { pluginName: 'CadastreNum', file: 'plugins/external/GMXPluginCadastreNum/CadastreNum.js', module: 'CadastreNum', mapPlugin: true, isPublic: true },
    //{pluginName: 'YtrafficPlugin', file: 'plugins/Ytraffic/ytrafficPlugin.js', module: 'YtrafficPlugin', mapPlugin: true, isPublic: true},

    { pluginName: 'fieldsFilter', file: 'plugins/fieldsFilter/fieldsFilter.js', module: 'fieldsFilter', mapPlugin: true },
	{ pluginName: 'WebglFilters', file: 'plugins/imageProcessing/WebglFilters.js', module: 'WebglFilters', mapPlugin: true },
    { pluginName: 'Sorting Plugin', file: 'plugins/vectorsorting/VectorSorting.js', module: 'VectorSorting', mapPlugin: true, isPublic: false },
    // { pluginName: 'GPS Tracks', file: 'plugins/GPSTracksPlugin.js', module: 'GPSTracksPlugin', mapPlugin: true },
    { pluginName: 'Express RC Creator', file: 'plugins/WMSSalesPlugin.js', module: 'WMSSalesPlugin', mapPlugin: true },
    { pluginName: 'SquareCalculation', file: 'plugins/SlickTotalSquare.js', module: 'SlickTotalSquare', mapPlugin: true },
    { pluginName: 'ProfilePlugin', file: 'plugins/ProfilePlugin/ProfilePlugin.js', module: 'ProfilePlugin', mapPlugin: true, isPublic: true },
    { pluginName: 'Virtual Layers', file: 'plugins/virtual_layers/VirtualLayers.js', module: 'VirtualLayersPlugin', mapPlugin: true },
    { pluginName: 'WWF Plugin', file: 'plugins/external/WWFAlert/frontend/WWFPlugin.js', module: 'WWFPlugin', mapPlugin: true },
    { pluginName: 'Shift Rasters Plugin', file: 'plugins/shiftrasters/ShiftRasterPlugin.js', module: 'ShiftRastersPlugin', mapPlugin: true },
    { pluginName: 'DayNightFiltering', file: 'plugins/DayNightFilteringPlugin.js', module: 'DayNightFilteringPlugin', mapPlugin: true, params: { layers: ["EB271FC4D2AD425A9BAA78ADEA041AB9", "533FCC7439DA4A2EB97A2BE77887A462"], dayNightAttribute: 'IsDay' } },
    { pluginName: 'Timeline Rasters', file: 'plugins/TimelineRCPlugin.js', module: 'TimelineRCPlugin', mapPlugin: true, isPublic: true },
	{ pluginName: 'TileBounds', file: 'plugins/VectorTiles/TileBounds.js', module: 'TileBounds', mapPlugin: true },
	{ pluginName: 'AISSearch', file: 'plugins/AIS/AISSearch/AISSearch.js', module: 'AISSearch', mapPlugin: true },
    { pluginName: 'AISImport', file: 'plugins/AISImportPlugin.js', module: 'AISImportPlugin', mapPlugin: true },
    { pluginName: 'Grid Analysis', file: 'plugins/grid_analysis/GridAnalysisPlugin.js', module: 'GridAnalysisPlugin', mapPlugin: true },
    { pluginName: 'Wikimapia', file: 'plugins/external/GMXPluginWikimapia/WikimapiaPlugin.js', module: 'WikimapiaPlugin', mapPlugin: true, isPublic: true, params: { key: "A132989D-FA1DF444-522EFAAB-B46998B7-19DD2782-09DC8A85-1286EF8C-A9D8DCC5", proxyUrl: "" } },
    { pluginName: 'BufferPlugin', file: 'plugins/external/GMXPluginBuffer/BufferPlugin.js', module: 'BufferPlugin', isPublic: true, mapPlugin: true },
    { pluginName: 'Add2Map', file: 'plugins/Add2MapPlugin.js', module: 'Add2MapPlugin', mapPlugin: true },
    { pluginName: 'Merge Layers Plugin', module: 'MergeLayersPlugin', file: 'plugins/mergelayers/MergeLayersPlugin.js', mapPlugin: true, isPublic: true },
    { pluginName: 'MultiRasterLayers', file: 'plugins/external/GMXPluginMultiRasterLayers/MultiRasterLayers.js', module: 'MultiRasterLayers', mapPlugin: true, isPublic: true},
    { pluginName: 'Wind Plugin', file: 'plugins/windplugin/WindPlugin.js', module: 'WindPlugin', mapPlugin: true, isPublic: true },
    { pluginName: 'GIBS Plugin', file: 'plugins/gibs/GIBSPlugin.js', module: 'GIBSPlugin', mapPlugin: true },
    { pluginName: 'GFW Plugin', file: 'plugins/gfw/GFWPlugin.js', module: 'GFWPlugin', mapPlugin: true, isPublic: true },
    { pluginName: 'Weather', file: 'plugins/WeatherPlugin.js', module: 'WeatherPlugin', mapPlugin: true, isPublic: true }
];

var gmxViewerUI = {
	logoImage: "logotypes/scanex_new_logo_eng.png",
	hideLogin : false, 
	hideLanguages: false, 
	headerLinks: true, 
	hideLogo: false
};

    mapHostName = "maps.kosmosnimki.ru";
    // defaultMapID = '946GH';

window.gmxVirtualClasses = {
    Cadastre: {module: 'CadastreVirtualLayer', file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginCadastre/GmxCadastreLayer.js'},
    GFW:      {module: 'GFWVirtualLayer',      file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginGFW/src/GmxGFWLayer.js'},
    GIBS:     {module: 'GIBSVirtualLayer',     file: 'http://maps.kosmosnimki.ru/api/plugins/gibs/leaflet-GIBS/src/GeoMixerGIBSLayer.js'},
    Fire:     {module: 'FireVirtualLayer',     file: 'http://maps.kosmosnimki.ru/api/plugins/fireplugin/FireVirtualLayer.js'}
};

	/*
var gmxDropBrowserCache = false;

gmxControls = 'controlsBaseIcons';


    var NDVIGraphicsParams = {
        proxyUrl: '',
        exMap: { host: "maps.kosmosnimki.ru", name: "PLDYO" },
        layers: {
            "LANDSAT8": {
                grid: "ndvi",
                caption: "NDVI",
                resolutionType: "LANDSAT",
                name: "2E9D38607BB4456AB9C04E2248ED5015",
                dateColumnName: "acqdate",
                sceneFieldName: "sceneid",
                yAxisDescr: ["NDVI"],
                ndviFunc: function (v) { return (v - 101) / 100; },
                palette: {
                    ndvi: {
                        url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                        prodtype: "NDVI"
                    },
                    quality: {
                        url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/legend_class_1-5.icxleg',
                        prodtype: "FIELD"
                    }
                }
            },
            "MODIS": {
                grid: "ndvi",
                caption: "NDVI16",
                resolutionType: "MODIS",
                name: "3AD0B4A220D349848A383D828781DF4C",
                dateColumnName: "lastday",
                yAxisDescr: ["NDVI"],
                palette: {
                    ndvi: {
                        url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                        prodtype: "NDVI16"
                    },
                    quality: {
                        url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/QC_grade_1-5.icxleg',
                        prodtype: "QUALITY16"
                    }
                },
                ndviFunc: function (v) {
                    var res = (v - 1.0) / 100.0;
                    return res;//(res <= 0.33 ? 0.0 : (res - 0.33));
                }
            },
            "TEMPERATURE": {
                grid: "temperature",
                caption: "Температура",
                weatherType: true,
                valueField: "AvgTemp",
                preSign: ["t", "Σt"],
                postSign: ["°", "°"],
                yAxisDescr: ["Температура (°C)", "Сумма тем-р (Σ°C)"],
                years: [2010, 2011, 2012, 2013, 2014, 2015, 2016]
            },
            "PRECIP": {
                grid: "precip",
                caption: "Осадки",
                weatherType: true,
                valueField: "Precip",
                preSign: ["p", "Σp"],
                postSign: ["", ""],
                yAxisDescr: ["Осадки (мм)", "Сумма осадков (Σ мм)"],
                years: [2010, 2011, 2012, 2013, 2014, 2015, 2016]
            },

            "RGB": {
                name: "04DDB23F49F84B9A9122CBA6BC26D3ED",
                dateColumnName: "acqdate",
                sceneFieldName: "SCENEID"
            },
            "RGB2": {
                name: "47A9D4E5E5AE497A8A1A7EA49C7FC336",
                dateColumnName: "ACQDATE",
                sceneFieldName: "SCENEID"
            },
            "CLASSIFICATION": {
                name: "0C94757D72C34876AD1CFEEE9FD8E902",
                dateColumnName: "acqdate",
                sceneFieldName: "sceneid",
                palette: {
                    classification: {
                        url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/CLASS_grade_1-5.icxleg',
                        prodtype: "CLASSIFICATION"
                    }
                }
            }
        }
    }

    window.isFirePluginVisible = false;
    // window.isTimelinePluginVisible = true;
    
    defaultMapID = "TDIE6";
	//defaultMapID = "V4G8N";
    
    window.gmxPlugins.push({
        pluginName: 'Photo Style Plugin',
        file: 'http://maps.kosmosnimki.ru/api/plugins/PhotoStyle/PhotoStylePlugin.js',
        module: 'PhotoStylePlugin'
    });
       
    window.gmxPlugins.push({
        file: 'http://maps.kosmosnimki.ru/api/plugins/agro_plugins_api_v2/ndviGraphics/main.js',
        module: 'NDVIGraphicsPlugin',
        params: NDVIGraphicsParams
    });

    window.gmxPlugins.push({
        file: 'http://maps.kosmosnimki.ru/api/plugins/reliefLayer/main.js',
        module: 'ReliefLayerPlugin'
    });

    window.gmxPlugins.push({ pluginName: 'CosmosagroStaticPlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/agro_plugins_api_v2/cosmosagroStatic/main.js', module: 'CosmosagroStaticPlugin' });
	window.gmxPlugins.push({ pluginName: 'AgroTagPlugin', file: 'plugins/external/GMXPluginAgro/agrotag/main.js', module: 'AgroTagPlugin' });
    window.gmxPlugins.push({ pluginName: 'AgroKubanPlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/agro_plugins_api_v2/agroKuban/agroKuban.js', module: 'AgroKubanPlugin' });
    window.gmxPlugins.push({ pluginName: 'AgroReportPlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/agroReport/main.js', module: 'AgroReportPlugin' });

    window.gmxPlugins.push({
        pluginName: 'NDVITimelinePlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/agro_plugins_api_v2/ndviTimeline/main.js', module: 'NDVITimelinePlugin', mapPlugin: true, isPublic: true,
        params: {
            proxyUrl: '',
            exMap: { host: "maps.kosmosnimki.ru", name: "PLDYO" },
            layers: {
                "MODIS": {
                    viewTimeline: true,
                    name: "3AD0B4A220D349848A383D828781DF4C",
                    dateColumnName: "lastday",
                    palette: {
                        ndvi: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                            prodtype: "NDVI16"
                        },
                        quality: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/ndvipublic/legend/QC_grade_1-5.icxleg',
                            prodtype: "QUALITY16"
                        }
                    }
                },
                "HR": {
                    name: "2E9D38607BB4456AB9C04E2248ED5015",
                    dateColumnName: "acqdate",
                    palette: {
                        ndvi: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                            prodtype: "NDVI"
                        },
                        quality: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/ndvipublic/legend/legend_class_1-5.icxleg',
                            prodtype: "FIELD"
                        }
                    }
                },
                "SENTINEL": {
                    viewTimeline: true,
                    name: "58A10C3522764BA69D2EA75B02E8A210",
                    dateColumnName: "acqdate"
                },
                "SENTINEL_NDVI": {
                    name: "2DFFD2B32C754770BD7D289AB8986CC4",
                    dateColumnName: "acqdate",
                    palette: {
                        ndvi: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                            prodtype: "NDVI"
                        }
                    }
                },
                "RGB": {
                    viewTimeline: true,
                    name: "04DDB23F49F84B9A9122CBA6BC26D3ED",
                    dateColumnName: "ACQDATE"
                },
                "RGB2": {
                    name: "47A9D4E5E5AE497A8A1A7EA49C7FC336",
                    dateColumnName: "ACQDATE"
                },
                "CLASSIFICATION": {
                    name: "0C94757D72C34876AD1CFEEE9FD8E902",
                    dateColumnName: "acqdate",
                    palette: {
                        classification: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/ndvipublic/legend/CLASS_grade_1-5.icxleg',
                            prodtype: "CLASSIFICATION"
                        }
                    }
                },
                "FIRES": {
                    name: "F2840D287CD943C4B1122882C5B92565",
                    dateColumnName: "DateTime",
                    timelineMode: "screen",
                    viewTimeline: true
                },
                "OPERATIVE_MODIS_AQUA_NDVI": {
                    viewTimeline: true,
                    name: "D0EC9464BFBE4A09BA0EEDF983CBBA08",
                    dateColumnName: "acqdate",
                    palette: {
                        ndvi: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                        }
                    }
                },
                "OPERATIVE_MODIS_TERRA_NDVI": {
                    viewTimeline: true,
                    name: "6CCDFB87663D431CA0B22CCDE4892859",
                    dateColumnName: "acqdate",
                    palette: {
                        ndvi: {
                            url: 'http://maps.kosmosnimki.ru/api/plugins/palettes/NDVI_interp_legend.icxleg.xml',
                        }
                    }
                }
            },
            combo: [{
                caption: "Композиты 16 дн",
                rk: ["MODIS"]
            }, {
                caption: "Космосъемка 10-30 м",
                rk: ["HR", "RGB", "RGB2", "CLASSIFICATION", "SENTINEL", "SENTINEL_NDVI"]
            }, {
                caption: "Космосъемка 250 м",
                rk: ["OPERATIVE_MODIS_AQUA_NDVI", "OPERATIVE_MODIS_TERRA_NDVI"]
            }, {
                caption: "Пожары",
                rk: ["FIRES"]
            }]
        }
    });


    window.gmxPlugins.push({ pluginName: 'FieldsTablePlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/agro_plugins_api_v2/fieldsTable/main.js', module: 'FieldsTablePlugin' });
    
    window.gmxPlugins.push({module: 'DefaultMapPlugin', 
        params: {
            'ins_npsk':       '6D7TL',
            'agro_krasnodar': 'ODH2V',
            'agro_rostov':    '1NKOB',
            'agro_rshb':      'S5EZP',
            'demo_user':      'V4G8N',
            'agro_tatarstan': '7AKU9',
            'agro_omsk':      '1UW4S',
            'agro_niva':      '4NQXO',
            'alexandern@scanex.ru': 'V4G8N',
            'agro_perm': 'VF6QE',
            'allianz' : 'PPIDH',
            'agro_bioton' : '2AC5EB78930F4C3EA3D37957060BEDAF',
            'demo.cosmosagro@yandex.ru' : 'UYFM2',
			'agro_prodimex':'1C4C3643B4224BE194309E70F50727DA',
			'proj':'TDIE6',
			'agro_tambov':'F54AB57E82EF437D9D8C211ADAC65E43',
			'ins_rshb':'99C710E60F5343D58E881D4AB37F647B',
			'agro_novomos': 'F4F6EA8F53CD43939D3409178754A742',
			'agro_uzbekistan': '615D73BE8E4247AA8996A092F3F0A768',
			'agro_ekoniva':'BEC471AFF71D4FA6862C44DA1EE8EBF5',
			'rosagro': '7C7F59F0251F41F38DD0884AEC709389',
			'agro_kuban': '572A7257F2CC443A9A84032B1E540A7A',
			'agro_sunprod':'29000F9FF94E49F79C6375E6DED2F1FF',
			'agro_mordovia':'RDIAR',
			'agro_nat':'9D92FD7E78784066A5926A8AC2299139',
			'agro_rostov_bokovskiy':'83E6C30A6B844A31BEB75B514DF25681',
            'agro_brazil':'18FDF9F1059F4055AFF2436880A29833',
			'agro_razguliay-group':'AE07DBC562A54F9A930739C40ACAF43D',
			'agro_miratorg':'030D541FC05D4F298E704A4E83ED49B0',
			'e.gricina@belpig.ru':'030D541FC05D4F298E704A4E83ED49B0',
            'y.eltsov@belpig.ru': '030D541FC05D4F298E704A4E83ED49B0',
			'moscow_nat':'E9B678B0FD7446F29C4FE59B3D80DA6B',
			'empty':'02C629BD617942699566E2006A750432',
			'agro_culture':'3937D34F0E774C2B9DFF993D73A1A03C',
			'empty':'TX8XR',
			'agro_saratov':'4709BC7880BA4C8DB4EE75A8538D6202',
			'agro_balashov':'1911B571B4274D3CB1DDB24EF8013284',
			'saratov_3reg':'TX8XR',
			'empty':'7O465',
			'kazminsky@mail.stv.ru':'99E8E6407CCE4650A5A0F8CB37A8D1F9',
			'kuban@agro-soft.ru':'472B75A1CF074C8C93C62EA8EE82E6A1',
			'empty':'2A49654F11AE41E7BDD6D7CD0472925B',
			'empty':'DB4BA9363706431E8F3DB515542E1E61',
            'agro_holdingkea': 'DB4BA9363706431E8F3DB515542E1E61',
			'ovoshevod':'63BDC58EFE8945A58050A432A163FEA4',
			'titov':'650DFA137BB74183B81A92167FE999DA',
			'vostok':'3E86EC314D514089B3207D52C317D88C',
			'spk_lenina':'AD4D5F9940844601A232916638770F0A',
			'urozhainoe':'B9D6BF406CF641D9ABAD7CD4064EF5D2',
			'nakonechnoe':'66D0505505B44F858EB4A202EB94AFB3',
			'nauka_as':'C20B7528578A40D89C16F4892792CD2F',
            'pole-st@mail.ru':'AAAB80D3CCD7483CAED6D36E884E5B33',
			'empty':'37F4CA641DA8478895C39E932ABAE1C5',
			'novosibirskagro456@mail.ru':'V4G8N',
            'agro_smeta':'E9470D5D16D94A48967C957CBE04E36B',
			'trunovskoe':'2DE70F95D27541D9B9D2865B23AE954B'
        }, plugin: {
        beforeMap: function(params) {
            var login = nsGmx.AuthManager.getLogin();
            login = login && login.toLowerCase();
            if (login in params) {
                window.defaultMapID = params[login];
            }
        }
    }})
    
    // window.gmxPlugins.push({ pluginName: 'Weather', file: 'http://maps.kosmosnimki.ru/api/plugins/WeatherPlugin.js', module: 'WeatherPlugin', mapPlugin: true, isPublic: true });
    window.gmxPlugins.push({ pluginName: 'MiratorgPlugin', file: 'http://maps.kosmosnimki.ru/api/plugins/miratorg/miratorg.js', module: 'MiratorgPlugin', mapPlugin: true });

	apiKey		= "Z2SSNR87N4";

//для отладки новой версии кадастрового плагина

window.gmxPlugins.push({pluginName: 'Fire Plugin',       file: 'plugins/fireplugin/FirePlugin.js',             module: 'FirePlugin',             mapPlugin: true, isPublic: !!window.isFirePluginVisible});

//для отладки Leaflet версии
window.gmxPlugins.push({
    plugin: {
        beforeMap: function(params, map)
        {
            $(nsGmx.AuthManager).change(function()
            {
                if (nsGmx.AuthManager.isRole(nsGmx.ROLE_ADMIN))
                    window.gmxUseLeaflet = true;
            });
        }
    }
})

var gmxPluginGroups = [
    {
        eng: 'Agro plugins',
        rus: 'Агро плагины',
        plugins: ["NDVIGraphicsPlugin", "test_NDVITimelinePlugin", "NDVITimelinePlugin", "ReliefLayerPlugin", "FieldsTablePlugin", "AgroReportPlugin", "test_FieldsTablePlugin", "AgroKubanPlugin", "test_CosmosagroStaticPlugin", "CosmosagroStaticPlugin", "Agro"]
    }, {
        eng: 'Others',
        rus: 'Разные',
        plugins: ["WebglFilters", "TileBounds", "Photo Plugin", "Express Sales", "querySearch", "Router", "GPS Tracks", "WWF Plugin", "Google Maps", "Express RC Creator", "rubki", "SquareCalculation", "Walrus", "SearchRasterDemo", "DiffDemoPlugin", "Pixel Chart", "Cart", "3DDemo"]
    }
];

window.gmxPlugins.push({
    pluginName: 'WeatherGraphicsPlugin',
    file: 'http://maps.kosmosnimki.ru/api/plugins/weatherGraphics/main.js',
    module: 'WeatherGraphicsPlugin',
    mapPlugin: true,
    params: {
        proxyUrl: '',
        exMap: { host: "maps.kosmosnimki.ru", name: "PLDYO" },
        products: {
            "PRECIP": {
                caption: "Осадки",
                name: "Precip",
                years: [2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015]
            }
        }
    }
});

window.gmxVirtualClasses = {
    //Cadastre: {module: 'CadastreVirtualLayer', file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginCadastre/GmxCadastreLayer.js'},
    GFW:      {module: 'GFWVirtualLayer',      file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginGFW/src/GmxGFWLayer.js'},
    GIBS:     {module: 'GIBSVirtualLayer',     file: 'http://maps.kosmosnimki.ru/api/plugins/gibs/leaflet-GIBS/src/GeoMixerGIBSLayer.js'},
    Fire:     {module: 'FireVirtualLayer',     file: 'plugins/fireplugin/FireVirtualLayer.js'}
};

// Begin: MedvedIcons
    //var medvedValues = ["барсук", "бобр", "глухарь", "тетерев", "лисица", "енотовидная собака", "ондатра", "волк", "бурый медведь"];
    var medvedParams = {
        iconText: 'Режим добавления объектов',
        select: 'Выбор зверя',
        setAll: "Выбрать все",
        unSetAll: "Отменить все",
        iconPrefix: 'http://maps.kosmosnimki.ru/GetImage.ashx?usr=khaibrik%40scanex.ru&img=',
        proxyUrl: '',
        
        layers: {
            'B141AAD4698A496B96C0BF6EB1AFA68B': {
                id: 'birds',
                iconPrefix: 'http://icons.iconarchive.com/icons/femfoyou/angry-birds/48/',
                icon: 'angry-bird-icon.png',
                //style: { width: '30px' },
                select: 'Вид птицы',
                attribute: 'Вид птицы',
                values: ["глухарь", "тетерев", "синица"]
            },
            'C44F463579DD466C8AF384CF9A853C23': {
                //icon: 'polygon_beer.png',
                iconText: 'Встречи с животными',
                attribute: 'Type',
                values: ['рысь', 'лось', 'олень', 'утки', 'гуси', 'лисица', 'волк', 'бурый медведь', 'куропатка', 'рябчик', 'болотно-луговая дичь', 'хищные птицы', 'кабан', 'красная книга']
            },
            'A538C16A1C684206900EF5302399909F': {
                iconText: 'Учет по следам',
                attributes: [
                    {
                        title: 'Выбор зверя',
                        name: 'Type',
                        values: ['рысь', 'волк', 'бурый медведь'],
                        result: {
                            name: 'Type'
                        }
                    },
                    {
                        title: 'Выбор маршрута',
                        select: {
                            layer: '98E7F1B3538A4C6A80C4F7678959BC21',
                            orderby: 'Date',
                            columns: '[{"Value":"Date"},{"Value":"Name"},{"Value":"geomixergeojson"}]',
                            id: 'Date',
                            name: 'Name'
                        }
                    }
                ],
                results: {
                    layer: 'A538C16A1C684206900EF5302399909F',
                    conf: {
                        'рысь': 0.2,
                        'волк': 0.12
                    },
                    orderby: 'Type',
                    groupby: '[{"Value":"Type"}, {"Value":"Date"}]',
                    columns: '[{"Value":"Type"},{"Value":"Date"},{"Value":"count(*)"}]'
                }
            },
            'E5C3F46612E346EBABE048BB3A2FBE73': {
                //icon: '%D0%BC%D0%B5%D1%81%D1%82%D0%B0_%D0%BE%D0%B1%D0%B8%D1%82%D0%B0%D0%BD%D0%B8%D1%8F.png',
                iconText: 'Локальные местообитания',
                select: 'Выбор зверя',
                attribute: 'Type',
                values: ["барсук", "бобр", "глухарь", "тетерев", "лисица", "енотовидная собака", "ондатра", "волк", "бурый медведь"]
            },
            'A573428D7A544F9CA2D5E2BD40C654CD': {
                //icon: 'polygon_walf.png',
                iconText: 'Площадные местообитания',
                select: 'Выбор зверя',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            '65858ACD8A9F4C4EA47EC9646A5B364F': {
                //icon: '%D0%B1%D0%B8%D0%BE%D1%82%D0%B5%D1%85%D0%BD%D0%B8%D1%8F.png',
                iconText: 'Биотехния',
                select: 'Выбор биотехнии',
                attribute: 'Name',
                values: ['кормохранилище', 'кормовая площадка', 'кормовое поле', 'база', 'аншлаг', 'вышка', 'живоловушка', 'галечник', 'солонец', 'порхалище', 'вольер', 'кормушка', 'искусственное']
            },
            '98E7F1B3538A4C6A80C4F7678959BC21': {
                iconText: 'Учет на маршрутах',
                select: 'Выбор маршрута',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            'DEA3512AC437488DBAA443E03CD354F0': {
                iconText: 'Учет многодневным окладом',
                select: 'Выбор маршрута',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            '4C071FC4C2A74B52AE9C01A8DAFAC2CA': {
                iconText: 'Учет на пробных площадках',
                select: 'Выбор маршрута',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            '492B0337A5A946299047566DF9135813': {
                iconText: 'Охотохозяйственная организация',
                select: 'Выбор маршрута',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            '89A99A0D91B64EBA9E268D71BA56B967': {
                iconText: 'Маркеры',
                select: 'Выбор маршрута',
                attribute: 'Type',
                values: ['группа_1', 'группа_2', 'группа_3', 'группа_4', 'группа_5']
            },
            '861C3341054A4501B5850B3ED4ADED22': {
                iconText: 'Фото',
                select: 'Выбор зверя',
                attribute: 'Type',
                values: ["барсук", "бобр", "глухарь", "тетерев", "лисица", "енотовидная собака", "ондатра", "волк", "бурый медведь", 'другое']
            }
        }
    };

    window.gmxPlugins.push({
        pluginName: 'MedvedIcons',
        file: 'plugins/external/GMXPluginMedved/MedvedIcons.js',
        module: 'MedvedIcons',
        mapPlugin: true,
        params: medvedParams
    });
    
    window.gmxPlugins.push({
        pluginName: 'Medved Timeline',
        file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginMedved/MedvedTimeline.js',
        module: 'MedvedTimeline',
        mapPlugin: true
    });
    
    window.gmxPlugins.push({
        pluginName: 'Medved Distance',
        file: 'http://maps.kosmosnimki.ru/api/plugins/external/GMXPluginMedved/MedvedDistance.js',
        module: 'MedvedDistance',
        mapPlugin: true
    });
// End: MedvedIcons
*/