/*
 Leaflet-GeoMixer, Leaflet plugin for visualization data from GeoMixer server
 (c) 2013-2016, RDC ScanEx
*/
